//package club.elitesocceracademy.elitesocceracademy;
//
//public class PlaceImage {
//
//    public void placeImage(float X, float Y) {
//        int touchX = (int) X;
//        int touchY = (int) Y;
//
//        // placing at bottom right of touch
//        CustomFormation.touchView2.setX(X);
//        CustomFormation.touchView2.setY(Y);
//
//        //placing at center of touch
////        int viewWidth = touchView2.getWidth();
////        int viewHeight = touchView2.getHeight();
////        viewWidth = viewWidth / 2;
////        viewHeight = viewHeight / 2;
////        touchView2.layout(touchX - viewWidth, touchY - viewHeight, touchX + viewWidth, touchY + viewHeight);
//
//    }
//}
